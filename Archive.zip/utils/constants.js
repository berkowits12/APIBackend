const ZENOTI_CONSTANTS = {
    BASE_URL: 'api.zenoti.com',
}

module.exports = ZENOTI_CONSTANTS;